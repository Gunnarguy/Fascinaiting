from .download import download
from .llm import llm
from .uninstall import uninstall
from .install import install